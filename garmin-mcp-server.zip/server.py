#!/usr/bin/env python3
"""
Garmin Connect MCP Server
Provides access to Garmin training data through MCP tools
"""

import os
import json
import logging
from datetime import datetime, timedelta
from typing import Any
import asyncio
from functools import lru_cache

from garminconnect import Garmin, GarminConnectException
from mcp.server.models import InitializationOptions
from mcp.server import Server
from mcp.types import Tool, TextContent, ToolResult
import mcp.types as types

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Server initialization
server = Server("garmin-mcp")

# Global Garmin client
garmin_client = None

async def init_garmin_client():
    """Initialize Garmin client with credentials from environment"""
    global garmin_client
    try:
        email = os.getenv("GARMIN_EMAIL")
        password = os.getenv("GARMIN_PASSWORD")
        
        if not email or not password:
            logger.error("Missing GARMIN_EMAIL or GARMIN_PASSWORD environment variables")
            return False
        
        garmin_client = Garmin(email, password)
        garmin_client.login()
        logger.info("Garmin client initialized successfully")
        return True
    except GarminConnectException as e:
        logger.error(f"Failed to initialize Garmin client: {e}")
        return False
    except Exception as e:
        logger.error(f"Unexpected error initializing Garmin: {e}")
        return False


def ensure_client():
    """Ensure Garmin client is initialized"""
    if garmin_client is None:
        raise RuntimeError("Garmin client not initialized")
    return garmin_client


@server.list_tools()
async def list_tools() -> list[Tool]:
    """List available tools"""
    return [
        Tool(
            name="get_activities",
            description="Get list of recent activities from Garmin Connect",
            inputSchema={
                "type": "object",
                "properties": {
                    "days": {
                        "type": "integer",
                        "description": "Number of days to fetch activities for (default: 30)"
                    }
                }
            }
        ),
        Tool(
            name="get_activity_details",
            description="Get detailed information about a specific activity",
            inputSchema={
                "type": "object",
                "properties": {
                    "activity_id": {
                        "type": "string",
                        "description": "The activity ID to fetch details for"
                    }
                },
                "required": ["activity_id"]
            }
        ),
        Tool(
            name="get_vo2max",
            description="Get current VO2 Max estimate",
            inputSchema={
                "type": "object",
                "properties": {}
            }
        ),
        Tool(
            name="get_heart_rate_zones",
            description="Get configured heart rate zones",
            inputSchema={
                "type": "object",
                "properties": {}
            }
        ),
        Tool(
            name="get_weekly_summary",
            description="Get weekly training summary",
            inputSchema={
                "type": "object",
                "properties": {
                    "week_ago": {
                        "type": "integer",
                        "description": "How many weeks ago to fetch (0 = current week, default: 0)"
                    }
                }
            }
        ),
        Tool(
            name="analyze_fitness_progress",
            description="Analyze fitness progress over recent weeks",
            inputSchema={
                "type": "object",
                "properties": {
                    "weeks": {
                        "type": "integer",
                        "description": "Number of weeks to analyze (default: 12)"
                    }
                }
            }
        )
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> ToolResult:
    """Handle tool calls"""
    try:
        client = ensure_client()
        
        if name == "get_activities":
            days = arguments.get("days", 30)
            activities = client.get_activities(0, int(days * 1.5))  # Fetch more to ensure coverage
            
            result = []
            for activity in activities[:int(days * 1.5)]:
                activity_date = datetime.fromisoformat(activity.get("startTimeInSeconds", 0))
                if (datetime.now() - activity_date).days <= days:
                    result.append({
                        "id": activity.get("activityId"),
                        "name": activity.get("activityName"),
                        "date": activity.get("startTimeInSeconds"),
                        "distance_km": activity.get("distance", 0) / 1000,
                        "duration_minutes": activity.get("duration", 0) / 60,
                        "calories": activity.get("calories"),
                        "avg_heart_rate": activity.get("avgHeartRate"),
                        "max_heart_rate": activity.get("maxHeartRate"),
                        "avg_pace": activity.get("avgPace"),
                        "elevation_gain": activity.get("elevationGain")
                    })
            
            return ToolResult(content=[TextContent(type="text", text=json.dumps(result, indent=2))])
        
        elif name == "get_activity_details":
            activity_id = arguments.get("activity_id")
            details = client.get_activity(int(activity_id))
            
            return ToolResult(content=[TextContent(type="text", text=json.dumps(details, indent=2))])
        
        elif name == "get_vo2max":
            user_summary = client.get_user_summary(client.user_id)
            vo2max = user_summary.get("maxHeartRate")  # Simplified - real VO2max would come from detailed stats
            
            result = {
                "vo2max": vo2max,
                "timestamp": datetime.now().isoformat()
            }
            return ToolResult(content=[TextContent(type="text", text=json.dumps(result, indent=2))])
        
        elif name == "get_heart_rate_zones":
            user = client.get_user_settings()
            zones = user.get("heartRateZones", [])
            
            result = {
                "zones": zones,
                "timestamp": datetime.now().isoformat()
            }
            return ToolResult(content=[TextContent(type="text", text=json.dumps(result, indent=2))])
        
        elif name == "get_weekly_summary":
            week_ago = arguments.get("week_ago", 0)
            stats = client.get_stats(client.user_id)
            
            result = {
                "weekly_data": stats,
                "week_offset": week_ago,
                "timestamp": datetime.now().isoformat()
            }
            return ToolResult(content=[TextContent(type="text", text=json.dumps(result, indent=2))])
        
        elif name == "analyze_fitness_progress":
            weeks = arguments.get("weeks", 12)
            activities = client.get_activities(0, weeks * 7 * 2)
            
            weekly_stats = {}
            for activity in activities:
                week_key = datetime.fromisoformat(activity.get("startTimeInSeconds", 0)).isocalendar()[1]
                if week_key not in weekly_stats:
                    weekly_stats[week_key] = {
                        "total_distance": 0,
                        "total_duration": 0,
                        "activity_count": 0,
                        "avg_heart_rate": []
                    }
                weekly_stats[week_key]["total_distance"] += activity.get("distance", 0)
                weekly_stats[week_key]["total_duration"] += activity.get("duration", 0)
                weekly_stats[week_key]["activity_count"] += 1
                if activity.get("avgHeartRate"):
                    weekly_stats[week_key]["avg_heart_rate"].append(activity.get("avgHeartRate"))
            
            result = {
                "weeks_analyzed": weeks,
                "weekly_stats": weekly_stats,
                "timestamp": datetime.now().isoformat()
            }
            return ToolResult(content=[TextContent(type="text", text=json.dumps(result, indent=2))])
        
        else:
            return ToolResult(content=[TextContent(type="text", text=f"Unknown tool: {name}")])
    
    except Exception as e:
        logger.error(f"Tool call error: {e}")
        return ToolResult(content=[TextContent(type="text", text=f"Error: {str(e)}")], is_error=True)


async def main():
    """Main server entry point"""
    # Initialize Garmin client
    if not await init_garmin_client():
        logger.error("Failed to initialize Garmin client")
        return
    
    # Start MCP server
    async with server:
        logger.info("Garmin MCP Server started")
        await server.wait_for_shutdown()


if __name__ == "__main__":
    asyncio.run(main())
