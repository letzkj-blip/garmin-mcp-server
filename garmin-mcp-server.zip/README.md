# Garmin MCP Server

Ein Model Context Protocol (MCP) Server für Garmin Connect Trainings-Daten.

## Features

- 📊 6 MCP Tools für Garmin-Daten
- 🏃 Aktivitäten abrufen
- 📈 Fitness-Fortschritt analysieren
- 💓 Herzfrequenz-Zonen auslesen
- ⚡ Optimiert für Railway Deployment

## Tools

1. **get_activities** - Liste der letzten Aktivitäten
2. **get_activity_details** - Details zu einer einzelnen Aktivität
3. **get_vo2max** - Aktueller VO2 Max Wert
4. **get_heart_rate_zones** - Konfigurierte Herzfrequenz-Zonen
5. **get_weekly_summary** - Wöchentliche Trainings-Zusammenfassung
6. **analyze_fitness_progress** - Fitness-Fortschritt über mehrere Wochen

## Installation lokal

```bash
git clone https://github.com/letzkj-blip/garmin-mcp-server.git
cd garmin-mcp-server
pip install -r requirements.txt

# Umgebungsvariablen setzen
export GARMIN_EMAIL="your@email.com"
export GARMIN_PASSWORD="yourpassword"

python server.py
```

## Deployment auf Railway

### 1. GitHub Repository

Das Repo ist bereits erstellt. Die Dateien sind hochgeladen.

### 2. Railway Project erstellen

1. Geh zu https://railway.app
2. Klick **"New Project"** → **"Deploy from GitHub"**
3. Wähle **`garmin-mcp-server`** Repo
4. Railway deployed automatisch

### 3. Umgebungsvariablen setzen

Im Railway Dashboard:
1. Klick auf das Projekt
2. Geh zu **"Variables"**
3. Füge hinzu:
   - `GARMIN_EMAIL` = `Letzkj@gmail.com`
   - `GARMIN_PASSWORD` = `Recken7595.`
4. Speichern → Railway deployed automatisch neu

### 4. Server-URL kopieren

Nach dem Deploy:
1. Geh zu **"Deployments"** im Railway Dashboard
2. Kopiere die **Domain URL** (z.B. `https://garmin-mcp-abc123.railway.app`)
3. Diese URL kannst du in Claude verwenden

## Tägliches Update der Daten

Der Server läuft kontinuierlich auf Railway:
- ✅ Keine Neustart nötig
- ✅ Jeden Tag verfügbar
- ✅ Kostenlos (mit Railway $5 Guthaben)

Wenn Railway den Server stoppt: Er startet automatisch neu.

## Claude Integration

Sobald der Server läuft, kannst du mir die Server-URL geben:

```
Mein Server läuft auf: https://garmin-mcp-abc123.railway.app
```

Dann kann ich automatisch deine Daten täglich abrufen.

## Kosten

- **Railway:** $0 (du hast $5 Guthaben kostenlos)
- Dieser Server verbraucht **< $1/Monat**
- **Nie Bezahlung nötig**

## Support

Falls Probleme:
1. Geh zu Railway Dashboard → "Logs" → schau nach Fehlern
2. Prüf die Umgebungsvariablen (Email/Passwort richtig?)
3. Probiere einen Neustart: Railway Dashboard → "Redeploy"

---

**Gebaut für Jeff · Garmin Training Dashboard**
